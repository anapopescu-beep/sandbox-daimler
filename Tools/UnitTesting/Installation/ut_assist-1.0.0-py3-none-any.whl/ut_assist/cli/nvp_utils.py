import getopt
import sys

from ..unittest.mockup_xml_utils import nvp_mock_generate_from_excel

def _usage():
    print("Create the Nvm Mock xml from the excel file")
    print("nvp_utils [-m] [--excle arg] [--xml arg] [-h|-help]")
    print("   -m          : to generate the mock up xml")
    print("   --excel arg : the name of the excel file")
    print("   --xml arg   : the name of the xml file")
    sys.exit(2)

def nvp_utils_cli():
    try:
        opts, _ = getopt.getopt(sys.argv[1:], "mh", ["help", "excel=", "xml="])
    except getopt.GetoptError as err:
        # print help information and exit:
        print(str(err))  # will print something like "option -a not recognized"
        _usage()
    
    excel = None
    xml   = None
    action = None
    for o, arg in opts:
        if o in ("--excel"):
            excel = arg
        elif o in ("--xml"):
            xml = arg
        elif o in ("-m"):
            action = "mockup"
        elif o in ("-h", "--help"):
            _usage()
        else:
            assert False, "unhandled option"

    if (action == None):
        _usage()

    if (action == "mockup"):
        if (excel == None):
            print("Please enter the excel name")
        elif (xml == None):
            print("Please enter the xml name")
        else:
            nvp_mock_generate_from_excel(excel, xml)

if __name__ == "__main__":
    nvp_utils_cli()