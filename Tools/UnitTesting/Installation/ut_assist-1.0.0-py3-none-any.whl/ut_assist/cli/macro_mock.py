import getopt
import sys

from ..unittest.mockup_xml_utils import macro_mock_generate_from_source

def _usage():
    print("Create the Macro Mock xml from the C header file")
    print("macro_mock [--source arg] [--xml arg] [-h|-help]")
    print("   --source arg : the name of the C header file")
    print("   --xml arg    : the name of the xml file")
    sys.exit(2)

def macro_mock_cli():
    try:
        opts, _ = getopt.getopt(sys.argv[1:], "h", ["help", "source=", "xml="])
    except getopt.GetoptError as err:
        # print help information and exit:
        print(str(err))  # will print something like "option -a not recognized"
        _usage()
    
    source = None
    xml   = None
    action = "mockup"
    for o, arg in opts:
        if o in ("--source"):
            source = arg
        elif o in ("--xml"):
            xml = arg
        elif o in ("-h", "--help"):
            _usage()
        else:
            assert False, "unhandled option"
            _usage()

    if (action == "mockup"):
        if (source == None):
            print("Please enter the source file name")
            _usage()
        elif (xml == None):
            print("Please enter the xml file name")
            _usage()
        else:
            macro_mock_generate_from_source(source, xml)

if __name__ == "__main__":
    macro_mock_cli()
