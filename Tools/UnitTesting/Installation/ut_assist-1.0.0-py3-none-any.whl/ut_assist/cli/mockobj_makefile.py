from ..unittest.mockup_xml import MockObjXmlReader
from ..models.mockup import Functionality
from typing import List
import sys, glob
import getopt
import os

def _usage():
    print("Create the Mock Object makefile for the unit testing")
    print("mockobj_make [--folder arg] [--makefile arg] [-h|-help]")
    print("   --folder   arg : the folder contains the mock ojbect XML files")
    print("   --makefile arg : the name of the makefile file")
    sys.exit(2)

def cli():
    try:
        opts, _ = getopt.getopt(sys.argv[1:], "mh", ["help", "folder=", "makefile="])
    except getopt.GetoptError as err:
        # print help information and exit:
        print(str(err))  # will print something like "option -a not recognized"
        _usage()
    
    folders  = []
    makefile = None
    action = "mockup"
    for o, arg in opts:
        if o in ("--folder"):
            folders.append(arg)
        elif o in ("--makefile"):
            makefile = arg
        elif o in ("-h", "--help"):
            _usage()
        else:
            assert False, "unhandled option"
            _usage()

    if (action == "mockup"):
        if (len(folders) == 0):
            print("Please enter the folder name")
            _usage()
        elif (makefile == None):
            print("Please enter the xml file name")
            _usage()
        else:
            generate_makefile(folders, makefile)

def generate_makefile(folders: List[str], makefile: str):
    srcs = []
    xmls = []
    for folder in folders:
        for filename in glob.glob(folder + "/*.xml"):
            functionality = Functionality()
            reader = MockObjXmlReader()
            reader.read(filename, functionality)
            if (functionality.source_file != ""):
                srcs.append(os.path.basename(functionality.source_file))
            srcs.append(os.path.basename(functionality.header_file))
            xmls.append(os.path.basename(filename))

    with open(makefile, "w") as f_out:
        f_out.write("SRCS = \\\n")
        for src in srcs:
            f_out.write("\t%s \\\n" % ("mocks/" + src))
        f_out.write("\n")

        f_out.write("XMLS = \\\n")
        for xml in xmls:
            f_out.write("\t%s \\\n" % ("xml/" + xml))
        f_out.write("\n")

        f_out.write("$(SRCS) : $(XMLS)\n")
        f_out.write("\tJAVA -jar S:/Tools/UnitTesting/Workspace/MockGen/MockGen.jar -m -c CIL --src xml -dst mocks\n")

if __name__ == "__main__":
    cli()   