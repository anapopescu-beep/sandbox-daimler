import getopt
import sys

from ..unittest.mockup_xml_utils import nvp_mock_generate_from_source

def _usage():
    print("Create the Nvm Mock xml from the C source file")
    print("nvp_mock [--source arg] [--xml arg] [-h|-help]")
    print("   --source arg : the location of the C source or header file")
    print("   --header arg : the location of the Nvp_Generated.h")
    print("   --xml arg    : the name of the xml file")
    sys.exit(2)

def nvp_mock_cli():
    try:
        opts, _ = getopt.getopt(sys.argv[1:], "mh", ["help", "source=", "header=", "xml="])
    except getopt.GetoptError as err:
        # print help information and exit:
        print(str(err))  # will print something like "option -a not recognized"
        _usage()
    
    sources = []
    nvp_generated = ""
    xml   = None
    action = "mockup"
    for o, arg in opts:
        if o in ("--source"):
            sources.append(arg)
        elif o in ("--xml"):
            xml = arg
        elif o in ("--header"):
            nvp_generated = arg
        elif o in ("-h", "--help"):
            _usage()
        else:
            assert False, "unhandled option"
            _usage()

    if (action == "mockup"):
        if (len(sources) == 0):
            print("Please enter the source file name")
            _usage()
        elif (xml == None):
            print("Please enter the xml file name")
            _usage()
        else:
            try:
                nvp_mock_generate_from_source(sources, nvp_generated,  xml)
            except Exception as e:
                print(e)

if __name__ == "__main__":
    nvp_mock_cli()
