import getopt
import sys
import xml.etree.ElementTree as ET

from ar_model import AUTOSAR, ARPackage, AtomicSwComponentType, VariableAccess, ServerCallPoint, SwComponentType, DataTypeMappingSet, RPortPrototype
from ar_model import ApplicationDataType, ImplementationDataType, ClientServerOperation, CompuMethod, Compu, CompuContent, CompuConstTextContent
from ar_model import InternalTriggerOccurredEvent, NonqueuedReceiverComSpec, PPortPrototype, RunnableEntity, OperationInvokedEvent, ApplicationError
from ar_model import ARXMLParser
from ..unittest.mockup_xml import MockupXmlWriter
from ..models.mockup import Functionality, IncludeFile, RteSenderReceiver, Typedef, StructType, StructTypeElement
from ..models.mockup import Function, Parameter, Macro, Prototype, AbstractFunction


def set_functionality(functionality: Functionality, component: str):
    functionality.name = component
    functionality.source_file = "Rte_%s.c" % component
    functionality.header_file = "Rte_%s.h" % component

def add_include_files(functionality: Functionality):
    include_file = IncludeFile()
    include_file.name = "Rte.h"
    functionality.add_include_file(include_file)

def process_com_spec(port, data_element, functionality: Functionality):
    if (isinstance(port, RPortPrototype)):
        for com_spec in port.required_com_specs:
            if (isinstance(com_spec, NonqueuedReceiverComSpec)):
                if (com_spec.enable_updated == True):
                    function = Function()
                    function.return_type = "boolean"
                    function.name = "Rte_IsUpdated_%s_%s" % (port.short_name, data_element.short_name)
                    functionality.add_function(function)


def process_autosar_variable(document: AUTOSAR, suffix: str, variable_access: VariableAccess, functionality: Functionality):
    port = document.find(variable_access.accessed_variable_ref.autosar_variable_in_impl_datatype.port_prototype_ref.value)  # type: RPortPrototype
    data_element = document.find(variable_access.accessed_variable_ref.autosar_variable_in_impl_datatype.target_data_prototype_ref.value)
    data_type = document.find(data_element.type_tref.value)
    if (isinstance(data_type, ApplicationDataType)):
        process_appl_data_type(document, data_type, functionality)
        data_type = document.convertToImplementationDataType(data_type.full_name)

    rte_sender_receiver = RteSenderReceiver()
    rte_sender_receiver.name = "%s_%s_%s" % (suffix, port.short_name, data_element.short_name)
    rte_sender_receiver.type = data_type.short_name
    functionality.add_function(rte_sender_receiver)

    process_impl_data_type(document, data_type, functionality)
    process_com_spec(port, data_element, functionality)


def process_local_variable(document: AUTOSAR, suffix: str, variable_access: VariableAccess, functionality: Functionality):
    variable = document.find(variable_access.accessed_variable_ref.local_variable_ref.value)  # type: RPortPrototype
    data_type = document.find(variable.type_tref.value)
    if (isinstance(data_type, ApplicationDataType)):
        process_appl_data_type(document, data_type, functionality)
        data_type = document.convertToImplementationDataType(data_type.full_name)

    rte_sender_receiver = RteSenderReceiver()
    rte_sender_receiver.name = "%s_%s" % (suffix, variable.short_name)
    rte_sender_receiver.type = data_type.short_name
    functionality.add_function(rte_sender_receiver)

    process_impl_data_type(document, data_type, functionality)


def process_compu_method(document: AUTOSAR, compu_method: CompuMethod, functionality: Functionality):
    if (compu_method.category == CompuMethod.CATEGORY_TEXTTABLE):
        compu_content = compu_method.compu_internal_to_phys.compu_content   # type: CompuScales
        for compu_scale in compu_content.getCompuScales():
            if (compu_scale.lower_limit.value != compu_scale.upper_limit.value):
                raise ValueError("lower limit shall be same as upper limit")
            macro = Macro()
            macro.name = compu_scale.compu_inverse_value.vt
            macro.value = compu_scale.lower_limit.value
            functionality.add_macro(macro)


def process_appl_data_type(document: AUTOSAR, data_type: ApplicationDataType, functionality: Functionality):
    if (data_type.sw_data_def_props != None):
        if (data_type.sw_data_def_props.compu_method_ref != None):
            compu_method = document.find(
                data_type.sw_data_def_props.compu_method_ref.value)
            process_compu_method(document, compu_method, functionality)


def process_typedef_type(document: AUTOSAR, data_type: ImplementationDataType, functionality: Functionality):
    referred_type = document.getDataType(data_type)

    typedef = Typedef()
    typedef.name = data_type.short_name

    if (data_type.category == ImplementationDataType.CATEGORY_DATA_REFERENCE):
        typedef.type = referred_type.short_name + " * "
    else:
        typedef.type = referred_type.short_name

    functionality.add_data_type(typedef)


def process_impl_struct_member_type(document: AUTOSAR, data_type: ImplementationDataType, functionality: Functionality):
    for sub_element in data_type.getImplementationDataTypeElements():
        if (sub_element.sw_data_def_props != None):
            if (sub_element.category == ImplementationDataType.CATEGORY_TYPE_REFERENCE):
                data_type = document.find(sub_element.sw_data_def_props.implementation_data_type_ref.value)
                process_typedef_type(document, data_type, functionality)

                if (isinstance(data_type, ImplementationDataType)):
                    data_type = document.convertToApplicationDataType(data_type.full_name)  # type: ApplicationDataType
                    if (data_type.sw_data_def_props.compu_method_ref != None):
                        compu_method = document.find(data_type.sw_data_def_props.compu_method_ref.value)
                        process_compu_method(document, compu_method, functionality)


def process_impl_struct_type(document: AUTOSAR, data_type: ImplementationDataType, functionality: Functionality):
    type_struct = StructType()
    type_struct.name = data_type.short_name

    for sub_element in data_type.getImplementationDataTypeElements():
        type_struct_element = StructTypeElement()
        type_struct_element.name = sub_element.short_name

        if (sub_element.sw_data_def_props != None):
            if (sub_element.category == ImplementationDataType.CATEGORY_TYPE_REFERENCE):
                data_type = document.find(sub_element.sw_data_def_props.implementation_data_type_ref.value)
                type_struct_element.type = data_type.short_name
            elif (sub_element.category == ImplementationDataType.CATEGORY_TYPE_VALUE):
                base_type = document.find(sub_element.sw_data_def_props.base_type_ref.value)
                type_struct_element.type = base_type.short_name
            else:
                raise ValueError("Invalid type category <%s>" %
                                 sub_element.category)

        type_struct.addStructTypeElement(type_struct_element)
    functionality.add_data_type(type_struct)


def process_impl_data_type(document: AUTOSAR, data_type: ImplementationDataType, functionality: Functionality):
    if (data_type.category == ImplementationDataType.CATEGORY_TYPE_REFERENCE):
        process_typedef_type(document, data_type, functionality)
    elif (data_type.category == ImplementationDataType.CATEGORY_DATA_REFERENCE):
        process_typedef_type(document, data_type, functionality)
    elif (data_type.category == ImplementationDataType.CATEGORY_TYPE_STRUCTURE):
        process_impl_struct_member_type(document, data_type, functionality)
        process_impl_struct_type(document, data_type, functionality)

    if (data_type.sw_data_def_props != None):
        if (data_type.sw_data_def_props.compu_method_ref != None):
            compu_method = document.find(data_type.sw_data_def_props.compu_method_ref.value)
            process_compu_method(document, compu_method, functionality)


def process_operation(document: AUTOSAR, operation: ClientServerOperation, function: AbstractFunction, functionality: Functionality):
    for argument in operation.getArgumentDataPrototypes():
        data_type = document.find(argument.type_tref.value)
        if (isinstance(data_type, ApplicationDataType)):
            process_appl_data_type(document, data_type, functionality)
            data_type = document.convertToImplementationDataType(data_type.full_name)

        parameter = Parameter()
        parameter.name = argument.short_name
        parameter.direction = argument.direction
        parameter.type = data_type.short_name
        if (parameter.direction == "OUT" or parameter.direction == "INOUT"):
            parameter.type = parameter.type
        elif (parameter.direction == "IN" and data_type.category == ImplementationDataType.CATEGORY_TYPE_STRUCTURE):
            parameter.type = "const " + parameter.type + " * "

        function.addParameter(parameter)

        process_impl_data_type(document, data_type, functionality)

    if len(operation.getPossbileErrorRefs()) > 0:
        function.return_type = "Std_ReturnType"
    else:
        function.return_type = "void"

    for possible_error in operation.getPossbileErrorRefs():
        if (possible_error.dest == "APPLICATION-ERROR"):
            application_error = document.find(possible_error.value) # type: ApplicationError
            error_macro = Macro()
            error_macro.name = "RTE_E_" + operation.parent.short_name + "_" + application_error.short_name
            error_macro.value = str(application_error.error_code)
            functionality.add_macro(error_macro)


def process_server_call(document: AUTOSAR, server_call_point: ServerCallPoint, functionality: Functionality):
    if (server_call_point.operation_iref == None):
        print("Invalid Operation reference <%s>" % server_call_point.short_name)
        return

    port = document.find(server_call_point.operation_iref.context_r_port_ref.value)                  # type: RPortPrototype
    operation = document.find(server_call_point.operation_iref.target_required_operation_ref.value)  # type: ClientServerOperation

    function = Function()
    function.name = "Rte_Call_%s_%s" % (port.short_name, operation.short_name)

    process_operation(document, operation, function, functionality)

    functionality.add_function(function)


def process_internal_trigger_occurred_event(document: AUTOSAR, event: InternalTriggerOccurredEvent, functionality: Functionality):
    point = document.find(event.event_source_ref.value)
    if (point != None):
        function = Function()
        function.name = "Rte_IrTrigger_%s_%s" % (
            point.parent.short_name, point.short_name)
        functionality.add_function(function)


def process_timing_event(document: AUTOSAR, event: InternalTriggerOccurredEvent, functionality: Functionality):
    if (event.start_on_event_ref != None):
        entity = document.find(event.start_on_event_ref.value)  # type: RunnableEntity
        prototype = Prototype()
        prototype.name = entity.symbol
        functionality.add_prototype(prototype)


def process_operation_invoked_event(document: AUTOSAR, event: OperationInvokedEvent, functionality: Functionality):
    if (event.start_on_event_ref == None or event.operation_iref == None):
        print("Invalid Operation Invoked Event <%s>" % event.short_name)
        return

    entity = document.find(event.start_on_event_ref.value)
    #port = document.find(event.operation_iref.context_p_port_ref.value)                 # type: PPortPrototype
    operation = document.find(event.operation_iref.target_provided_operation_ref.value) # type: ClientServerOperation

    prototype = Prototype()
    prototype.name = entity.symbol

    process_operation(document, operation, prototype, functionality)

    functionality.add_prototype(prototype)


def process_behavior(document: AUTOSAR, sw_component: AtomicSwComponentType, functionality: Functionality):
    for entity in sw_component.internal_behavior.getRunnableEntities():
        for dsp in entity.getDataSendPoints():
            process_autosar_variable(document, "Rte_Write", dsp, functionality)
        for drpa in entity.getDataReceivePointByArguments():
            process_autosar_variable(document, "Rte_Read", drpa, functionality)
        for drpv in entity.getDataReceivePointByValues():
            process_autosar_variable(
                document, "Rte_DRead", drpv, functionality)
        for dra in entity.getDataReadAccesses():
            process_autosar_variable(document, "Rte_IRead_%s" % entity.short_name, dra, functionality)
        for dwlv in entity.getWrittenLocalVariables():
            process_local_variable(document, "Rte_IrvWrite_%s" % entity.short_name, dwlv, functionality)
        for drlv in entity.getReadLocalVariables():
            process_local_variable(document, "Rte_IrvRead_%s" % entity.short_name, drlv, functionality)
        for scp in entity.getServerCallPoints():
            process_server_call(document, scp, functionality)
    for event in sw_component.internal_behavior.getInternalTriggerOccurredEvents():
        process_internal_trigger_occurred_event(document, event, functionality)

    for event in sw_component.internal_behavior.getOperationInvokedEvents():    # type: OperationInvokedEvent
        process_operation_invoked_event(document, event, functionality)

    for event in sw_component.internal_behavior.getTimingEvents():
        process_timing_event(document, event, functionality)


def process_sw_component(document: AUTOSAR, sw_component: SwComponentType, functionality: Functionality, component: str):
    if (sw_component.short_name == component):
        print("%s is found" % component)
        set_functionality(functionality, component)
        add_include_files(functionality)

        if (isinstance(sw_component, AtomicSwComponentType)):
            process_behavior(document, sw_component, functionality)


def process_ar_package(document: AUTOSAR, ar_package: ARPackage, functionality: Functionality, component: str):
    # for data_type in ar_package.getImplementationDataTypes():
    #    show_type(indent + 2, data_type)
    # for mapping_set in ar_package.getDataTypeMappingSets():
    #    show_data_type_mapping(indent + 2, mapping_set)
    for sw_component in ar_package.getAtomicSwComponentTypes():
        process_sw_component(document, sw_component, functionality, component)
    for child_pkg in ar_package.getARPackages():
        process_ar_package(document, child_pkg, functionality, component)


def process(document: AUTOSAR, functionality: Functionality, component: str):
    print("")
    print("Start to convert ARXML to mockup configuration XML...")
    for child_pkg in document.getARPackages():
        process_ar_package(document, child_pkg, functionality, component)


def _usage():
    print("Generate the RTE mock object XML from ARXML")
    print("arxml_mock --arxml arg --xml arg -h")
    print("   --arxml arg : the file name of the arxml file")
    print("   --xml   arg : the file name of mock object xml file")
    print("   -c      arg : the component name")
    print("   -h          : show the help information")
    sys.exit(2)


def cli_main():
    try:
        opts, _ = getopt.getopt(sys.argv[1:], "c:h", [
                                "arxml=", "xml=", "help"])
    except getopt.GetoptError as err:
        # print help information and exit:
        print(str(err))  # will print something like "option -a not recognized"
        _usage()

    arxml_files = []
    xml_file = ""
    component = ""
    for o, arg in opts:
        if o in ("--arxml"):
            arxml_files.append(arg)
        elif o in ("--xml"):
            xml_file = arg
        elif o in ("-c"):
            component = arg
        elif o in ("-h", "--help"):
            _usage()
        else:
            print("unhandled option %s" % o)
            _usage()

    if (len(arxml_files) == 0):
        print("Please specific the arxml file name")
        _usage()

    if (xml_file == ""):
        print("Please specific the xml file name")
        _usage()

    if (component == ""):
        print("Please specific the component name")
        _usage()

    try:
        ar_doc = AUTOSAR().getInstance()
        functionality = Functionality()

        parser = ARXMLParser()
        writer = MockupXmlWriter()

        for arxml_file in arxml_files:
            parser.load(arxml_file, ar_doc)

        process(ar_doc, functionality, component)

        writer.write(xml_file, functionality)
    except Exception as e:
        print(e)

