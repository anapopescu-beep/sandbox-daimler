import getopt
import sys

from ..unittest.folder import unittest_folder_create

def _usage(error: str):
    if (error != ""):
        print(error)
    print("Create the default folder structure for unittest")
    print("alvtest [-c name][-p mainstream|extended] [-h|-help]")
    print("   -c arg : the name of the component")
    print("   -p arg : the name of PP4G platform")
    sys.exit(2)

def unittest_cli():
    try:
        opts, _ = getopt.getopt(sys.argv[1:], "hc:p:", ["help"])
    except getopt.GetoptError as err:
        # print help information and exit:
        print(str(err))  # will print something like "option -a not recognized"
        _usage()
    
    component = ""
    platform = ""
    for o, arg in opts:
        if o in ("-c"):
            component = arg
        elif o in ("-h", "--help"):
            _usage()
        elif o in ("-p"):
            platform = arg
        else:
            assert False, "unhandled option"

    if (component == ""):
        _usage()

    if (platform.lower() not in ["extended", "mainstream"]):
        _usage('Unsupported Platform parameter <%s>.' % platform)
    
    try:
        unittest_folder_create('makefile', platform, component)
    except Exception as e:
        print(e)

if __name__ == "__main__":
    unittest_cli()
