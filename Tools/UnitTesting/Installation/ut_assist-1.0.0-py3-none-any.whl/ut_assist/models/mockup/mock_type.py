from typing import List

class AbstractType:
    def __init__(self):
        self.name = ""

class EnumTypeElement:
    def __init__(self):
        self.name = ""
        self.value = ""

class EnumType(AbstractType):
    def __init__(self):
        super().__init__()

        self.elements = [] # type: List[EnumTypeElement]

class StructTypeElement:
    def __init__(self):
        self.name = ""
        self.type = ""

class StructType(AbstractType):
    def __init__(self):
        super().__init__()

        self.elements = [] # type: List[StructTypeElement]

    def addStructTypeElement(self, element: StructTypeElement):
        for item in self.elements:
            if (item.name == element.name):
                return
        self.elements.append(element)

    def getStructTypeElements(self) -> List[StructTypeElement]:
        return self.elements


class Typedef(AbstractType):
    def __init__(self):
        super().__init__()

        self.type = ""


