from typing import List
from .mock_type import AbstractType, Typedef, EnumType, StructType
from abc import ABCMeta

class IncludeFile:
    def __init__(self):
        self.name = ""

class AbstractVariable(metaclass=ABCMeta):
    def __init__(self):
        self.name = ""

class Variable(AbstractVariable):
    def __init__(self):
        self.type = ""
        self.value = ""

class Array(AbstractVariable):
    def __init__(self):
        self.type = ""
        self.size = None

class Parameter:
    def __init__(self):
        self.name = ""
        self.type = ""
        self.direction = ""

class Macro:
    def __init__(self):
        self.name = ""
        self.value = ""

class AbstractFunction:
    def __init__(self):
        self.name = ""
        self.return_type = ""
        self._parameters = []            # type: List[Parameter]

    def addParameter(self, parameter: Parameter):
        for item in self._parameters:
            if (item.name == parameter.name):
                return
        self._parameters.append(parameter)

    def getParameters(self) -> List[Parameter]:
        return self._parameters


class Function(AbstractFunction):
    def __init__(self):
        super().__init__()
    
class Prototype(AbstractFunction):
    def __init__(self):
       super().__init__()

class RteSenderReceiver(AbstractFunction):
    def __init__(self):
        self.type = ""

class Functionality:
    def __init__(self):
        self.name = ""
        self.header_file = ""
        self.source_file = ""
        self.wrap_file = ""
        self._include_files = {}        # type: Dict[IncludeFile]
        self._types = []                # type: List[AbstractType]
        self._type_sets = {}            # type: Dict[str]
        self._macros = {}               # type: Dict[Macro]
        self._functions = {}            # type: Dict[Function]
        self._prototypes = {}           # type: Dict[Prototype]
        self._variables = {}            # type: Dict[Variable]

    def add_variable(self, variable: AbstractVariable):
        if (variable.name not in self._variables.keys()):
            self._variables[variable.name] = variable

    def get_variables(self) -> List[AbstractVariable]:
        return sorted(self._variables.values(), key=lambda p: p.name)

    def add_include_file(self, include_file: IncludeFile):
        if (include_file.name not in self._include_files.keys()):
            self._include_files[include_file.name] = include_file

    def get_include_files(self) -> List[IncludeFile]:
        return self._include_files.values()

    def add_function(self, function: AbstractFunction):
        if (function.name not in self._functions.keys()):
            self._functions[function.name] = function

    def get_functions(self) -> List[AbstractFunction]:
        return sorted(self._functions.values(), key=lambda v: v.name)

    def add_prototype(self, prototype: Prototype):
        if (prototype.name not in self._prototypes.keys()):
            self._prototypes[prototype.name] = prototype

    def get_prototypes(self) -> List[Prototype]:
        return sorted(self._prototypes.values(), key=lambda v: v.name)

    def add_data_type(self, data_type: AbstractType):
        if (data_type.name not in self._type_sets):
            self._type_sets[data_type.name] = data_type.name
            self._types.append(data_type)

    def get_data_types(self) -> List[AbstractType]:
        return self._types

    def add_macro(self, macro: Macro):
        if (macro.name not in self._macros):
            self._macros[macro.name] = macro

    def get_macros(self) -> List[Macro]:
        return sorted(self._macros.values(), key=lambda v: v.name)

class MockupDoc:
    def __init__(self):
        self.Functionalities = {}   # type: Dict[Functionality]
