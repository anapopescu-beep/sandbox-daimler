from typing import List

""" Nvm Model Object """

class NvmData(object):
    def __init__(self):
        self._name = ""
        self._type = ""
        self._description = ""
        self._size = -1
        self._value = 0
        self._address = -1
        self._variable = ""

    @property
    def name(self) -> str:
        if (self._name == ""):
            raise ValueError("The name attribute can not be empty.")
        return self._name

    @name.setter
    def name(self, name: str):
        if (isinstance(name, str)):
            self._name = name
        else:
            raise TypeError("The name attribute shall be string %s." % type(name))

    @property
    def type(self) -> str:
        if (self._type == ""):
            raise ValueError("The type attribute can not be empty.")
        return self._type

    @type.setter
    def type(self, _type: str):
        if (isinstance(_type, str)):
            self._type = _type
        else:
            raise TypeError("The type attribute shall be string %s." % type(_type))

    @property
    def is_array(self) -> bool:
        return "[]" in self.type

    @property
    def variable(self) -> str:
        #if (self.variable == ""):
        #    raise ValueError("The variable attribute can not be empty.")
        return self._variable

    @variable.setter
    def variable(self, variable: str):
        if (isinstance(variable, str)):
            self._variable = variable
        else:
            raise TypeError("The type attribute shall be string %s." % type(variable))

    @property
    def size(self) -> int:
        if (self._size < 0):
            raise ValueError("The size must be larger than zero.")
        return self._size

    @size.setter
    def size(self, size: int):
        if (isinstance(size, int)):
            self._size = size
        else:
            raise TypeError("The type attribute shall be number %s." % type(size))

    @property
    def value(self) -> int:
        return self._value

    @value.setter
    def value(self, value: str):
        if (isinstance(value, str)):
            self._value = value
        else:
            raise TypeError("The type attribute shall be string %s." % type(value))

    def __str__(self):
        return "%s (%s)" % (self.name , self.variable)

class NvmBlock(object):
    def __init__(self):
        self._name = ""
        self._address = -1
        self._id = -1
        self.items = []

    @property
    def name(self) -> str:
        if (self._name == ""):
            raise ValueError("The name attribute can not be empty.")
        return self._name

    @name.setter
    def name(self, name: str):
        if (isinstance(name, str)):
            self._name = name
        else:
            raise TypeError("The name attribute shall be string %s." % type(name))

    @property
    def address(self) -> int:
        if (self._address < 0):
            raise ValueError("The address attribute shall be large than zero.")
        return self._address

    @address.setter
    def address(self, address: int):
        if (isinstance(address, int)):
            self._address = address
        else:
            raise TypeError("The address attribute shall be string %s." % type(address))

    @property
    def id(self) -> int:
        if (self._id < 0):
            raise ValueError("The block_id attribute shall be large than zero.")
        return self._id

    @id.setter
    def id(self, id: int):
        self._id = id

    def addNvmItem(self, item):
        self.items.append(item)

    def getNvmItems(self) -> List[NvmData]:
        return self.items

class NvmModel(object):
    def __init__(self):
        self.blocks = []

    def addBlock(self, block: NvmBlock):
        self.blocks.append(block)

    def getBlocks(self) -> List[NvmBlock]:
        return self.blocks