import xlrd
import re
import sys

from ..models.nvm_model import NvmModel, NvmData, NvmBlock

class NvmXlsException(Exception):
    pass

class NvmXls(object):

    CALIBRATION_SHEET = "Calibration (FLASH)"
    CALIBRATION_START_ROW = 10

    COL_ADDRESS         = 'FLASH ADDRESS Calibration Base Address'
    COL_PARAMETER_NAME  = 'PARAMETER NAME'
    COL_SOFTWARE_ALIAS  = 'SOFTWARE ALIAS in RAM'
    COL_SIZE            = 'SIZE'
    COL_VALUE           = 'VALUE'
    COL_VALUE_HEX       = 'VALUE (hex)'

class NvmXlsReader(object):
    def __init__(self):
        self.column_name_list = {
            NvmXls.COL_PARAMETER_NAME: -1,
            NvmXls.COL_SOFTWARE_ALIAS: -1,
            NvmXls.COL_SIZE : -1,
            NvmXls.COL_VALUE : -1,
            NvmXls.COL_ADDRESS: -1,
            NvmXls.COL_VALUE_HEX: -1,
        }

        self.current_block = None

        self.merged_column_name = {}

    def _get_data_type(self, name):
        if (name == "--"):
            return ""

        match = re.match(".*_(au32|u32|s32|au16|ku16|u16|s16|au8|u8|b8|s8).*", name)
        if (match):
            if (match.group(1) == "u32"):
                return "uint32"
            elif (match.group(1) == "s32"):
                return "sint32"
            elif (match.group(1) == "au32"):
                return "uint32[]"
            elif (match.group(1) == "au8"):
                return "uint8[]"
            elif (match.group(1) == "u8" or match.group(1) == "b8"):
                return "uint8"
            elif (match.group(1) == "au16"):
                return "uint16[]"
            elif (match.group(1) == "u16" or match.group(1) == "ku16"):
                return "uint16"
            elif (match.group(1) == "s16"):
                return "sint16"
            elif (match.group(1) == "s8"):
                return "sint8"
        raise NvmXlsException("Invalid data type <%s>" % name)

    def _read_calibration_column_header(self, sheet, row, num_of_columns):
        try:
            for k, v in sorted(self.merged_column_name.items()):
                _, _, cl, ch = v
                #print('[%s](%d , %d, %d, %d)' % (k, v[0], v[1], v[2], v[3]))
                if k in self.column_name_list.keys():
                    if (ch - cl > 1):
                        raise NvmXlsException("The column <%s> width is more than 1" % k)
                    self.column_name_list[k] = cl

        except IndexError as e:
            print(e)

        for (key, value) in self.column_name_list.items():
            if (value == -1):
                raise NvmXlsException("Column <%s> can not be found" % key)

    def _read_calibration_column_data(self, sheet, row, nvm_model: NvmModel):
        name = sheet.cell_value(row, self.column_name_list[NvmXls.COL_PARAMETER_NAME])

        if (name == ""):
            return

        size = int(sheet.cell_value(row, self.column_name_list[NvmXls.COL_SIZE]))

        cell = sheet.cell(row, self.column_name_list[NvmXls.COL_VALUE])
        if (cell.ctype != xlrd.XL_CELL_TEXT):
            value = int(cell.value)
        else:
            value = int(cell.value, 16)

        if (name == "u8PhysicalBlockId"):
            if (self.current_block != None):
                nvm_model.addBlock(self.current_block)
                self.current_block = None

            block = NvmBlock()
            block.id = int(value)
            block.name = sheet.cell_value(row, self.column_name_list[NvmXls.COL_SOFTWARE_ALIAS])

            if (size != 0):
                raise NvmXlsException("The size of Block <%s> is not zero" % block.name)

            self.current_block = block
            print("Block : %s [%d]" % (block.name, block.id))
            
        else:
            nvm_data = NvmData()

            nvm_data.name = name
            nvm_data.variable = sheet.cell_value(row, self.column_name_list[NvmXls.COL_SOFTWARE_ALIAS])
            nvm_data.type = self._get_data_type(nvm_data.variable)
            nvm_data.value = "%#x" % value
            nvm_data.size  = size

            self.current_block.addNvmItem(nvm_data)
            print("  Item : %s [%d] - %s" % (nvm_data.variable, nvm_data.size, nvm_data.value))

        

    def _read_calibration_sheet(self, book, nvm_model: NvmModel):            
        sheet = book.sheet_by_name(NvmXls.CALIBRATION_SHEET)

        if (sheet == None):
            raise NvmXlsException("Sheet <%s> can not be found." % NvmXls.CALIBRATION_SHEET)

        for crange in sheet.merged_cells:
            rlo, _, col, _ = crange
            range_text = sheet.cell_value(rlo, col)
            range_text = range_text.replace('\r', ' ')
            range_text = re.sub(r"\s+", " ", range_text)
            self.merged_column_name[range_text] = crange 
    
        if (sheet.nrows > NvmXls.CALIBRATION_START_ROW):
            self._read_calibration_column_header(sheet, NvmXls.CALIBRATION_START_ROW, sheet.ncols)

        for row in range(NvmXls.CALIBRATION_START_ROW, sheet.nrows):
            self._read_calibration_column_data(sheet, row, nvm_model)

        # add the last Nvm Block
        if (self.current_block != None):
            nvm_model.addBlock(self.current_block)
            self.current_block = None

    def read(self, excel_name, nvm_model: NvmModel): # type: (str, IoSparc) -> None
        try:
            with xlrd.open_workbook(excel_name, formatting_info = True) as book:
                self._read_calibration_sheet(book, nvm_model)
        except Exception as err:
            print(err)
            raise err
        