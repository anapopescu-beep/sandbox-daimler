import xml.etree.ElementTree as ET
from typing import List
from xml.dom import minidom
from ..models.mockup import MockupDoc, AbstractType, Typedef, StructType, StructTypeElement, Parameter, Prototype
from ..models.mockup import AbstractFunction, RteSenderReceiver, Function, Functionality, Variable , Array, IncludeFile, Macro

class MockupXmlWriter(object):
    def __init__(self):
        pass

    def writeFunctionality(self, root_tag, functionality: Functionality):
        functionality_tag = ET.SubElement(root_tag, "Functionality")
        functionality_tag.set('Name', functionality.name)
        functionality_tag.set('HeaderFile', functionality.header_file)
        if (functionality.source_file != ""):
            functionality_tag.set('SourceFile', functionality.source_file)

    def writeIncludeFiles(self, root_tag, include_files: List[IncludeFile]):
        if (len(include_files) > 0):
            include_files_tag = ET.SubElement(root_tag, "IncludeFiles")
            for include_file in include_files:
                include_file_tag = ET.SubElement(include_files_tag, "IncludeFile")
                include_file_tag.set("Name", include_file.name)

    def writeTypeDef(self, types_tag, data_type: Typedef):
        type_tag = ET.SubElement(types_tag, "Typedef")
        type_tag.set('Name', data_type.name)
        type_tag.set('Type', data_type.type)

    def writeStructType(self, types_tag, data_type: StructType):
        type_tag = ET.SubElement(types_tag, "Struct")
        type_tag.set('Name', data_type.name)
        for type_element in data_type.getStructTypeElements():
            element_tag = ET.SubElement(type_tag, "Element")
            element_tag.set('Name', type_element.name)
            element_tag.set('Type', type_element.type)

    def writeDataTypes(self, root_tag, data_types: List[AbstractType]):
        if (len(data_types) > 0):
            types_tag = ET.SubElement(root_tag, "Types")
            for data_type in data_types:
                if (isinstance(data_type, Typedef)):
                    self.writeTypeDef(types_tag, data_type)
                elif (isinstance(data_type, StructType)):
                    self.writeStructType(types_tag, data_type)
                else:
                    raise ValueError("Unsupported data type <%s>." % data_type.name)

    def writeMacros(self, root_tag, macros: List[Macro]):
        if (len(macros) > 0):
            macros_tag = ET.SubElement(root_tag, "Macros")
            for macro in macros:
                macro_tag = ET.SubElement(macros_tag, "Macro")
                macro_tag.set('Name', macro.name)
                macro_tag.set('Value', macro.value)

    def writeVariables(self, root_tag, variables: List[Variable]):
        if (len(variables) > 0):
            variables_tag = ET.SubElement(root_tag, "Variables")
            for variable in variables:
                if (isinstance(variable, Variable)):
                    variable_tag = ET.SubElement(variables_tag, "Variable")
                    variable_tag.set('Name', variable.name)
                    variable_tag.set('Type', variable.type)
                    if (variable.value != ""):
                        variable_tag.set('Value', variable.value)
                elif (isinstance(variable, Array)):
                    variable_tag = ET.SubElement(variables_tag, "Array")
                    variable_tag.set('Name', variable.name)
                    variable_tag.set('Type', variable.type)
                    if (variable.size != None):
                        variable_tag.set("Size", variable.size)
                    else:
                        variable_tag.set("Size", "")

    def writeParameter(self, parent_tag, parameter: Parameter):
        parameter_tag = ET.SubElement(parent_tag, "Parameter")
        parameter_tag.set('Name', parameter.name)
        parameter_tag.set("Direction", parameter.direction)
        parameter_tag.set("Type", parameter.type)

    def writeFunctions(self, root_tag, functions: List[AbstractFunction]):
        if (len(functions) > 0):
            functions_tag = ET.SubElement(root_tag, "Functions")
            for function in functions:
                if (isinstance(function, RteSenderReceiver)):
                    function_tag = ET.SubElement(functions_tag, "Rte_SenderReceiver")
                    function_tag.set('Name', function.name)
                    function_tag.set('Type', function.type)
                elif (isinstance(function, Function)):
                    function_tag = ET.SubElement(functions_tag, "Function")
                    function_tag.set('Name', function.name)
                    if (function.return_type != ""):
                        function_tag.set("ReturnType", function.return_type)
                    for parameter in function.getParameters():
                        self.writeParameter(function_tag, parameter)

    def writePrototypes(self, root_tag, prototypes: List[Prototype]):
        if (len(prototypes) > 0):
            prototypes_tag = ET.SubElement(root_tag, "Prototypes")
            for prototype in prototypes:
                prototype_tag = ET.SubElement(prototypes_tag, "Prototype")
                prototype_tag.set('Name', prototype.name)
                if (prototype.return_type != ""):
                    prototype_tag.set("ReturnType", prototype.return_type)
                for parameter in prototype.getParameters():
                    self.writeParameter(prototype_tag, parameter)

    def write(self, filename, functionality: Functionality):
        root_tag = ET.Element('Mock')
        root_tag.set("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance")
        root_tag.set("xsi:noNamespaceSchemaLocation", "Mock.xsd")

        self.writeFunctionality(root_tag, functionality)
        self.writeIncludeFiles(root_tag, functionality.get_include_files())
        self.writeMacros(root_tag, functionality.get_macros())
        self.writeDataTypes(root_tag, functionality.get_data_types())
        self.writeVariables(root_tag, functionality.get_variables())
        self.writeFunctions(root_tag, functionality.get_functions())
        self.writePrototypes(root_tag, functionality.get_prototypes())
        
        # create a new XML file with the results
        data = ET.tostring(root_tag, encoding="utf-8" ).decode("utf-8")
        reparsed = minidom.parseString(data)
        with open(filename, 'w') as f_out:
            f_out.write(reparsed.toprettyxml(indent="\t")) 
        
class MockObjXmlReader:
    def __init__(self):
        pass

    def readFunctionality(self, root_tag, functionality: Functionality):
        functionality_tag = root_tag.find(".//Functionality")
        if (functionality_tag == None):
            raise ValueError("Functionality Tag can not found")
        functionality.name = functionality_tag.attrib['Name']
        functionality.header_file = functionality_tag.attrib['HeaderFile']
        if 'SourceFile' in functionality_tag.attrib:
            functionality.source_file = functionality_tag.attrib['SourceFile']
        else:
            functionality.source_file = ""

    def read(self, filename, functionality: Functionality):
        tree = ET.parse(filename)
        root = tree.getroot()
        if (root.tag != "Mock"):
            raise ValueError("Invalid mock object xml %s" % filename)
        self.readFunctionality(root, functionality)