from ..models.nvm_model import NvmData, NvmBlock, NvmModel
from ..models.mockup import Functionality, Variable, IncludeFile, Macro, Array
from ..parsers.nvm_parser import NvmXlsReader
from .mockup_xml import MockupXmlWriter 
from typing import List

import re
import os.path

def nvp_mock_generate_from_excel(excel_name, xml_name):
    model = NvmModel() 

    reader = NvmXlsReader()
    reader.read(excel_name, model)

    functionality = Functionality()
    functionality.name = 'NVP'
    functionality.header_file = 'NVP_Generated.h'
    functionality.source_file = 'NVP_mock.c'

    for nvm_block in model.getBlocks():
        for nvm_item in nvm_block.getNvmItems():
            if (nvm_item.variable != "--"):
                if (nvm_item.is_array == False):
                    variable = Variable() 
                    variable.name = nvm_item.variable
                    variable.type = nvm_item.type
                    variable.value = nvm_item.value
                    functionality.add_variable(variable)

    writer = MockupXmlWriter()
    writer.write(xml_name, functionality)

def convert_data_type(type: str):
    if (type == "b8"):
        return "boolean"
    if (type == "u8"):
        return "uint8"
    elif (type == "u16"):
        return "uint16"
    elif (type == "u32"):
        return "uint32"
    elif (type == "s8"):
        return "sint8"
    elif (type == "s16"):
        return "sint16"
    elif (type == "s32"):
        return "sint32"
    else:
        raise ValueError("Unsupported data type %s" % type)

def nvp_mock_parse_nvp_generated_header_file(nvp_generated_file: str, functionality: Functionality):
    try:
        with open(nvp_generated_file,  encoding="utf-8") as f_in:
            content = f_in.readlines()

        for line in content:
            m = re.match(r'^\s*#define\s+(\w+)\s+(\(?\s*\w+\s*\)?)\s*', line)
            if (m != None):
                if (m.group(1) == "NVP_GENERATED_H_"):
                    continue
                macro = Macro() 
                macro.name = m.group(1)
                macro.value = m.group(2)
                functionality.add_macro(macro)
    except:
        print("<%s> is not accessible." % nvp_generated_file)

def nvp_mock_generate_from_source(source_files: List[str], nvp_generated_file: str, xml_file: str):

    functionality = Functionality()
    functionality.name = 'NVP'
    functionality.header_file = 'NVP_Generated.h'
    functionality.source_file = 'NVP_mock.c'

    include_file = IncludeFile()
    include_file.name = "Std_Types.h"
    functionality.add_include_file(include_file)

    if (nvp_generated_file != ""):
        nvp_mock_parse_nvp_generated_header_file(nvp_generated_file, functionality)

    for source_file in source_files:
        with open(source_file) as f_in:
            current_line = 0
            try:
                for line_no, line in enumerate(f_in):
                    current_line += 1
                    nvp_mock_parse_NVP_Variables(line, functionality)
            except UnicodeDecodeError as e:
                print("<%s>: <%d>" % (source_file, current_line))
                raise(e)

    writer = MockupXmlWriter()
    writer.write(xml_file, functionality)

def nvp_mock_parse_NVP_Variables(line, functionality: Functionality):
    matches = re.finditer(r'((?:K_)?NVP_(c?a?)(b8|u8|s8|u16|s16|u32|s32)\w+)', line)
    for m in matches:
        if ('a' in m.group(2)):
            variable = Array()
            variable.name = m.group(1)
            variable.type = convert_data_type(m.group(3))
            functionality.add_variable(variable)
        else:
            variable = Variable() 
            variable.name = m.group(1)
            variable.type = convert_data_type(m.group(3))
            functionality.add_variable(variable)
    
def convert_macro_data_value(value: str):
    m = re.match(r'\({2}(s|u)int(?:8|16|32)\)\s+(0x)?([\dA-F]+)\)', value)
    if (m != None):
        if (m.group(2) != None):
            hex_prefix = m.group(2)
        else:
            hex_prefix = ''
        if (m.group(1) == 'u'):
            return hex_prefix + m.group(3) + 'u'
        else:
            return hex_prefix + m.group(3)
    else:
        return value

def macro_mock_generate_from_source(source_file: str, xml_file: str):
    with open(source_file, encoding="utf-8") as f_in:
        content = f_in.readlines()

    basename = os.path.basename(source_file)

    functionality = Functionality()
    functionality.name = os.path.splitext(basename)[0]
    functionality.header_file = basename
    functionality.source_file = ''

    for line in content:
        m = re.match(r'^\s*#define\s+([\w(),]+)\s+([\w\s()&><?\-:^]+)', line)
        if (m != None):
            macro = Macro() 
            macro.name = m.group(1)
            macro.value = convert_macro_data_value(m.group(2).strip())
            functionality.add_macro(macro)

    writer = MockupXmlWriter()
    writer.write(xml_file, functionality)