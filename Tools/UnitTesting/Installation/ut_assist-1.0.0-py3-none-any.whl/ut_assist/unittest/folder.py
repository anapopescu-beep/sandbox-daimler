from ..utils.template import Templatelternative
from shutil import copyfile
from  configparser import ConfigParser

import os

INI_PATH = 'c:/Prog/UnitTesting/Config'
INI_NAME = INI_PATH + '/ut_assist.ini'

name_list = {
        'ATM': 'AutoTestManager',
        'BFE': 'BeltFunctionExecution',
        'BFS': 'BeltFunctionSelection',
        'BMM': 'BeltMovementMonitoring',
        'BPA': 'BeltParkingAlgorithm',
        'BSR': 'BeltSlackReduction',
        'CIL': 'CommunicationInteractionLayer',
        'DIA': 'DiagOnCAN',
        'EDR': 'EmergencyDataRecord',
        'ERH': 'ErrorHandler',
        'EOL': 'EndOfLifeManagement',
        'HWA': 'HapticWarning',
        'MIC': 'MemoryIntegrityControl',
        'MMG': 'ModeManagement',
        'NMH': 'History_Buffer',
        'NVP': 'NonVolatileParameters',
        'PAL': 'PowerAbstractionLayer',
        'PCM': 'PreCrashMaster',
        'PMP': 'PhysicalMeasuresProvider',
        'PRE': 'PreTensioning',
        'PRO': 'ProductionCycles',
        'QCM': 'QuiescentCurrentMonitor',
        'RCM': 'ResetCauseManagement',
        'SCM': 'SystemContextManagement',
        'SFR': 'StandardFunctionRecovery',
        'STM': 'SystemTimeManagement',
        'VDA': 'VehicleDynamicAlgorithm',
        'VIP': 'VdaInputsProcessing',
        'VMM': 'VehicleModeManagement',
    }

def _copy_file(src, dst):
    root_path = os.path.abspath(__file__ + '/../../unittest/tpls')
    copyfile(os.path.realpath(root_path + "/" + src), dst)

def _generate_config_file(src, dst, component, full_name):
    root_path = os.path.abspath(__file__ + '/../../unittest/tpls')

    with open(root_path + "/" + src) as f_in:
        content = f_in.read()
    
    t = Templatelternative(content)
    new_content = t.substitute(COMPONENT = component, FULL_NAME = full_name)

    with open(dst, 'w') as f_out:
       f_out.write(new_content) 

def _read_ini():
    ini_file = ""
    if os.path.exists(INI_NAME):
        ini_file = INI_NAME
    
    if ini_file != "":
        parser = ConfigParser()
        parser.read(ini_file)
        if ('components' in parser):
            for key in parser['components']:
                key = key.upper()
                #print("<%s> is <%s>" % (key, parser['components'][key]))
                name_list[key] = parser['components'][key]
    
def _get_full_name(component):
    if (component in name_list):
         return name_list[component]

    if not os.path.exists(INI_NAME):
        src = os.path.abspath(__file__ + '/../../unittest/tpls/config/ut_assist.ini')
        os.makedirs(INI_PATH, exist_ok=True)
        copyfile(src, INI_NAME)
    
    raise KeyError("Please specific the full component name in the <%s>" % INI_NAME)

def create_eclipse_plugin():
    eclipse_path = "C:/Prog/Eclipse/links"
    os.makedirs(eclipse_path, exist_ok=True)

    root_path = os.path.abspath(__file__ + '/../../unittest/tpls')
    copyfile(os.path.realpath(root_path + "/" + "eclipse_plugin.link.tpl"), os.path.realpath(eclipse_path + "/" + "com.autolive.ctc.unittesting.ui.link"))

def unittest_folder_create(eclipse, platform, component):
    _read_ini()

    if (platform == "extended"):
        platform_path = "pp4g_extended"
    else:
        platform_path = "pp4g_mainstream"

    full_name = _get_full_name(component.upper())

    create_folders()

    #print ("Generate mock.xml")
    #_generate_config_file('mock.bat.tpl', 'unittest/batch/mock.bat', component, full_name)
    
    print ("Generate makefile")
    _generate_config_file(platform_path + '/' + 'makefile.tpl', 'unittest/makefile', component, full_name)
    _generate_config_file(platform_path + '/' + 'makefile.config.tpl', 'unittest/makefile.config.mk', component, full_name)
    _generate_config_file('makefile.utilities.tpl', 'unittest/makefile.utilities.mk', component, full_name)

    print ("Generate .project")
    _generate_config_file(platform_path + '/' + '.%s_project.tpl' % eclipse, 'unittest/.project', component, full_name)

    print ("Generate .cproject")
    _generate_config_file(platform_path + '/' + '.%s_cproject.tpl' % eclipse, 'unittest/.cproject', component, full_name)

    print ("Generate common.xml")
    _copy_file('common.xml.tpl', 'unittest/xml/common.xml')

    print ("Generate config.xml")
    _copy_file('config.xml.tpl', 'unittest/xml/config.xml')

    print ("Generate memmap.xml")
    _generate_config_file('memmap.xml.tpl', 'unittest/xml/Rte_%s_AC_%s_memmap.xml' % (component, full_name), component, full_name)
    #_copy_file('memmap.xml.tpl', 'unittest/xml/memmap.xml')

    print ("Generate NVP.xml")
    _copy_file('NVP.xml.tpl', 'unittest/xml/NVP.xml')

    print ("Generate run_lcov.bat")
    _copy_file('run_lcov.bat.tpl', 'unittest/run_lcov.bat')

    print ("Generate Rte_%s.xml" % component)
    _generate_config_file('Rte_Module.xml.tpl', 'unittest/xml/Rte_%s_AC_%s.xml' % (component, full_name), component, full_name)

    print ("Generate %s_TestSuite.c" % component)
    _generate_config_file('Module_test.c.tpl', 'unittest/testcases/%s_TestSuite.c' % component, component, full_name)

    #print ("Generate Coverage.bat" )
    #_generate_config_file('coverage.bat.tpl', 'unittest/coverage/coverage.bat', component, full_name)

    print ("Generate Mock.xsd")
    _copy_file('Mock.xsd', 'unittest/xml/Mock.xsd')

def create_folders():
    #os.makedirs("unittest/batch", exist_ok=True)
    os.makedirs("unittest/mocks", exist_ok=True)
    os.makedirs("unittest/testcases", exist_ok=True)
    os.makedirs("unittest/testxls", exist_ok=True)
    os.makedirs("unittest/xml", exist_ok=True)
    os.makedirs("unittest/report", exist_ok=True)
    os.makedirs("unittest/output/objs", exist_ok=True)

    #print ("Add the Eclipse unit testing plugin ")
    #create_eclipse_plugin()